library(tidyverse)
library(dplyr)
library(readr)
library(gridExtra)
library(stargazer)
library(Hmisc)
library(fastDummies)
library(ggplot2)

getwd()

access_path <-"classification regression prediction/data/raw/"
file_name <- "recipe_site_traffic_2212.csv" 
traffic <- read.csv(paste0(access_path, file_name)) 
glimpse(traffic) 

dim(traffic)

table(duplicated(traffic))

describe(traffic)

protein_null <- traffic %>%
  filter(protein == 0)
print(protein_null)

traffic <- traffic %>%
  mutate_if(is.character, as.factor)

unique(traffic$recipe)

unique(traffic$servings)
describe(traffic$servings)



traffic <- traffic %>%
  mutate(
    servings = str_replace(servings, " as a snack","")
  ) %>%
  mutate(
    servings = as.integer(servings)
    )
unique(traffic$servings)

describe(traffic$servings)

describe(traffic$category)


category_normales <- c("Lunch/Snacks", "Beverages",
                       "Potato", "Vegetable", "Meat", 
                       "Chicken", "Pork", "Dessert", 
                       "Breakfast", "One Dish Meal")

print(category_normales)

category_enreg <- unique(traffic$category) 

print(category_enreg)

category_nouvelle <- setdiff(category_enreg,category_normales) 

cat("La categorie nouvelle constatée dans la base est: ",category_nouvelle)



traffic <- traffic %>%
  mutate(
    category = str_replace(category, "Chicken Breast","Chicken")
  ) 

unique(traffic$category)


traffic <- traffic %>%
  mutate(
    category = tolower(category),
    high_traffic = tolower (high_traffic)
  ) 

glimpse(traffic)



traffic %>%
  summarise(across(everything() , ~ mean(is.na(.x) ) ) ) %>%
  select(where(~ .x > 0))


traffic <- traffic %>%
  mutate(
    high_traffic = ifelse(is.na(traffic$high_traffic),"low",high_traffic) 
  )%>%
  mutate_if(is.character, as.factor)


missings_rows <- 
  traffic %>%
  filter(is.na(calories)&
              is.na(carbohydrate)&
              is.na(sugar)&
              is.na(protein)
              ) 

View(missings_rows)

missings_rows_percentage <- round((nrow(missings_rows)*100)/nrow(traffic), 2)

cat("la proportion totate de recettes ayant des valeurs manquantes à la fois pour 'calories' ,
    'carbohydrate' et 'sugar' est :",  missings_rows_percentage,"%" )



describe(traffic$high_traffic)


traffic_no_na <- 
  traffic %>%
  filter(!is.na(calories)|
           !is.na(carbohydrate)|
           !is.na(sugar)|
           !is.na(protein)
  ) 



describe(traffic_no_na$high_traffic)


traffic_f <- traffic_no_na # notons traffic_f notre nouvelle dataset
glimpse(traffic_f)

levels(factor(traffic_no_na$high_traffic))

# Histogramme et diagramme de densité du traffic en fonction de la quantité de 
# calories dans la recette 

ggplot(traffic_no_na, aes(x = calories, fill = factor(high_traffic))) + 
  geom_histogram(aes(y = after_stat(density)), alpha = 0.5, bins = 30, 
                 position = "identity") +
  
  geom_density(aes(color = factor(high_traffic)), linewidth = 1, fill = NA) +
  
  scale_fill_manual(
    values = c("low" = "grey", "high" = "#D62728"),
    labels = c("low" = "Low traffic", "high" = "High traffic")
  ) +
  
  scale_color_manual(
    values = c("low" = "yellow", "high" = "#D62728"),
    labels = c("low" = "Low traffic", "high" = "High traffic")
  ) +
  
  labs(
    fill = "Traffic level",
    color = "Traffic level",
    x = "Calories",
    y = "Traffic",
    title = "Distribution du traffic en fonction du nombre de calories dans 
    la recette"
  ) +
  
  theme_minimal()

# Diagramme de densité de l'évolution du traffic en fonction du gramme de sucre 
# dans la recette 

ggplot(traffic_no_na, aes(x = sugar, fill = high_traffic)) +
  
  geom_density(alpha = 0.5) +
  
  scale_fill_manual(
    values = c("low" = "purple", "high" = "orange"),
    labels = c("low" = "Low traffic", "high" = "High traffic")
  ) +
  
  labs(
    x = "Sugar",
    y = "Traffic",
    fill = "Traffic level",
    title = "Densité du traffic en fonction du gramme de sucre dans la recette"
  ) +
  
  theme_minimal()

# Diagramme en barre de l'évolution du traffic par rapport au nombre de 
# portions

ggplot(traffic_no_na, aes(x = factor(servings), fill = high_traffic)) +
  
  geom_bar(position = "dodge") +
  
  scale_fill_manual(
    values = c("low" = "pink", "high" = "orange"),
    labels = c("low" = "Low traffic", "high" = "High traffic")
  ) +
  
  labs(
    x = "Nombre de portions",
    y = "Traffic",
    fill = "Traffic level",
    title = "Diagramme en barre de l'évolution du traffic en fonction du nombre 
    de portions"
  ) +
  
  theme_minimal()

# Diagramme en barre et de densité de l'évolution du traffic en fonction du 
# gramme de protéine dans la recette

ggplot(traffic_no_na, aes(x = high_traffic, y = protein, fill = high_traffic)) +
  
  stat_summary(fun = mean, geom = "bar", width = 0.6) +
  
  scale_fill_manual(
    values = c("low" = "green", "high" = "blue"),
    labels = c("low" = "Low traffic", "high" = "High traffic")
  ) +
  
  labs(
    x = "Traffic",
    y = "Quantité moyenne de protéines en gramme",
    fill = "Traffic level",
    title = "Teneur moyenne en protéines selon le niveau de trafic"
  ) +
  
  theme_minimal()

# Histogramme de distribution du traffic en fonction du gramme de glucides 
# dans la recette 

ggplot(traffic_no_na, aes(x = carbohydrate, fill = high_traffic)) +
  
  geom_histogram(alpha = 0.5, bins = 30, position = "identity") +
  
  scale_fill_manual(
    values = c("low" = "red", "high" = "black"),
    labels = c("low" = "Low traffic", "high" = "High traffic")
  ) +
  
  labs(
    x = "Teneur en glucides en grammes",
    y = "Traffic",
    fill = "Traffic level",
    title = "Histogramme du niveau de trafic en fonction de la teneur en 
    gramme de glucides"
  ) +
  
  theme_minimal()

# Diagramme en barre de l'évolution du traffic en fonction de la catégorie de
# de la recette 

traffic_pct <- traffic_no_na %>%
  count(category, high_traffic) %>%
  group_by(category) %>%
  mutate(pct = n / sum(n))

ggplot(traffic_pct, aes(x = category, y = pct, fill = high_traffic)) +
  
  geom_col(position = "fill") +
  
  geom_text(
    aes(label = scales::percent(pct, accuracy = 1)),
    position = position_fill(vjust = 0.5),
    color = "black",
    size = 3
  ) +
  
  coord_flip() +
  
  scale_fill_manual(
    values = c("low" = "chocolate", "high" = "brown"),
    labels = c("Low traffic", "High traffic")
  ) +
  
  labs(
    x = "Catégorie de recette",
    y = "Proportion",
    fill = "Traffic level",
    title = "Distribution du niveau de trafic selon la catégorie de recette"
  ) +
  
  theme_minimal()

# Question 3 : 60/40 split train/test

set.seed(2453)

# Création de l’index pour le split
n <- nrow(traffic_no_na)
tr <- sample(n, round(n * 0.6))

# Training set
my_train <- traffic_no_na[tr, ]

# Test set
my_test  <- traffic_no_na[-tr, ]

# 10-fold CV using rsample
install.packages("rsample")
library(rsample)

set.seed(2453)
cv_splits <- vfold_cv(my_train, v = 10)
cv_splits


# 10-fold CV using caret
install.packages("caret")
library(caret)

install.packages("randomForest")
library(randomForest)

control <- trainControl(method = "cv", number = 10)

fit.rf_cv <- train(
  high_traffic ~ calories + sugar + protein + servings + carbohydrate 
  + category,
  data = my_train,
  method = "rf",
  trControl = control,
  metric = "Accuracy"
)

print(fit.rf_cv)
# Pas nécéssaire ?????


# Question 4 : 
# Estimation du linear probability model (LPM)

str(my_train)
my_train$high_traffic <- ifelse(my_train$high_traffic == "high", 1, 0)
my_test$high_traffic  <- ifelse(my_test$high_traffic == "high", 1, 0)

lpm <- lm(high_traffic ~ calories + sugar + protein + servings + carbohydrate, 
          data = my_train)
summary(lpm)
# Faut-il vraiment ignorer category ??

# Estimation du modèle logit

logit <- glm(high_traffic ~ calories + sugar + protein + servings + 
      carbohydrate, data = my_train, family = binomial(link = "logit"))
summary(logit)

# Comparons les effets marginaux pour les deux modèles 
install.packages("margins")
library(margins)

mfx_logit <- margins(logit)
summary(mfx_logit)

# Le LPM étant une régression linéaire avec une variable dépendante binaire, les
# coefficients estimés sont directement des effets marginaux

# Trouvons les t-statistiques
# Pour le LPM
t_lpm <- summary(lpm)$coefficients[-1, "t value"]


# Pour le modèle logit
t_logit <- summary(mfx_logit)$AME / summary(mfx_logit)$SE
names(t_logit) <- summary(mfx_logit)$factor

# Tableau d'importance des variables

library(tidyr)

importance_df <- data.frame(
  variable = names(t_lpm),
  LPM = abs(t_lpm),
  Logit = abs(t_logit[names(t_lpm)])
)

importance_long <- pivot_longer(
  importance_df,
  cols = c("LPM", "Logit"),
  names_to = "model",
  values_to = "t_stat"
)

# Diagramme en barres 

ggplot(importance_long, aes(x = variable, y = t_stat, fill = model)) +
  
  geom_col(position = "dodge") +
  
  scale_fill_manual(
    values = c("Logit" = "#FF1493", "LPM" = "#000080")
  ) +
  
  labs(
    x = "Variables",
    y = "Importance (|t-stat|)",
    fill = "Modèle",
    title = "Importance des variables selon LPM et Logit"
  ) +
  
  theme_minimal()

# Question 5
# Estimons un modèle de forêt aléatoire

library(ranger)
library(purrr)
library(yardstick)
library(tibble)
library(dplyr)

modf1 <- high_traffic ~ calories + carbohydrate + sugar + protein + servings + category

cores <- parallel::detectCores() ## for use in: `ranger::ranger` (parallel mode)

cores <- parallel::detectCores()

folds <- vfold_cv(train_data, v = 10, strata=high_traffic) # 10-fold cross-validation

 rf_model <- function(splits,mtry) {
    rf.fit <- ranger::ranger(modf1, data=analysis(splits), mtry=mtry,
                   num.threads = cores,
                   importance="impurity",probability = TRUE)

    holdout <- assessment(splits)

    temp_rf <- predict(rf.fit, holdout, type = "response")
    holdout$probs <- temp_rf$predictions[,2]

    holdout$class <- ifelse(holdout$probs > 0.5, 1, 0)

    holdout$class <- factor(holdout$class,
                                levels=c(0,1),
                                labels = c("Low","High"))

    holdout <- holdout %>% select(high_traffic, probs, class)
    holdout
 }

 mtry_seq <- 2:6

 results <- matrix(NA, length(mtry_seq),3,
              dimnames=list(NULL, c("mtry", "accuracy", "auc")))

 for (i in 1:length(mtry_seq)) {
    results[i,1] <- mtry_seq[i]
    folds$results  <- purrr::map(folds$splits,rf_model,mtry=mtry_seq[i])
    folds$accuracy <- purrr::map_dbl(folds$results,
                            function(x) mean(x$high_traffic == x$class) )

    folds$AUC <- purrr::map_dbl(folds$results,
                     function(x) yardstick::roc_auc(x,truth = high_traffic,probs,
                                       event_level = "second")$.estimate)
    results[i,2] <- mean(folds$accuracy)
    results[i,3] <- mean(folds$AUC)
 }

 results <- as_tibble(results)

 cols <- c("accuracy"="blue","auc"="red")

ggplot(results, aes(x=mtry)) +
     geom_point(aes(y=accuracy,color="accuracy")) +
     geom_line(aes(y=accuracy,color="accuracy")) +
     geom_point(aes(y=auc, color="auc")) +
     geom_line(aes(y=auc, color="auc")) +
     theme_bw() +
     scale_colour_manual(name="performance metrics",values=cols) +
     theme(legend.position = "top")

 results

 m_op = results$mtry[which.max(results$auc)]
print(m_op)

rf.fit <- ranger::ranger(modrf1 , data=train_data, mtry=m_op,
                   num.threads = cores,
                   importance="impurity",probability = TRUE)

print(rf.fit)




# # Variable importance
rf.fit$variable.importance
VIMP_rf = tibble(Variable = names(rf.fit$variable.importance),
                Importance=rf.fit$variable.importance)
 
ggplot(VIMP_rf,aes(reorder(Variable, Importance), Importance)) +
   geom_col() +
   coord_flip() +
   labs(x="", y="VIMP score", title="RF VIMP") +
theme_bw()